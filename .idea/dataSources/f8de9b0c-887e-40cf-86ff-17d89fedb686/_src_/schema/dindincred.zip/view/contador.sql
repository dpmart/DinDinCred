CREATE VIEW contador AS
  SELECT
    (SELECT count(0)
     FROM `dindincred`.`email`
     WHERE (`dindincred`.`email`.`status` = 1))   AS `valido`,
    (SELECT count(0)
     FROM `dindincred`.`email`
     WHERE (`dindincred`.`email`.`status` = 2))   AS `invalido`,
    (SELECT count(0)
     FROM `dindincred`.`email`
     WHERE isnull(`dindincred`.`email`.`status`)) AS `Não Processado`;
